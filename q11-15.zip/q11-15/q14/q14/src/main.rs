fn primes(limit: usize) -> Vec<usize> {
    let mut is_prime = vec![true; limit + 1];
    is_prime[0] = false;
    is_prime[1] = false;

    for num in 2..=(limit as f64).sqrt() as usize {
        if is_prime[num] {
            for multiple in (num * num..=limit).step_by(num) {
                is_prime[multiple] = false;
            }
        }
    }

    let primes: Vec<usize> = is_prime
        .iter()
        .enumerate()
        .filter_map(|(i, &is_prime)| if is_prime { Some(i) } else { None })
        .collect();

    primes
}

fn main() {
    let n = 500;
    let primes = primes(n);

    println!("Prime numbers up to {}: {:?}", n, primes);
}
