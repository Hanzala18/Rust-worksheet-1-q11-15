fn reverse(input:&str) -> String{
    let rev:String= input.chars().rev().collect();
    rev

}
fn main() {
    let main ="Hanzala";
    let rev = reverse(main);
    println!("{} main",main);
    println!("{} reversed",rev);
}
