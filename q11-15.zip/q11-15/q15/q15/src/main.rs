fn modify_string(mut input_string: String) -> String {
    
    input_string.push_str(" (modified)");
    input_string
}

fn main() {
    let original_string = String::from("Hanzala");

    let modified_string = modify_string(original_string.clone());

    println!("Original string: {}", original_string);
    println!("Modified string: {}", modified_string);
}
