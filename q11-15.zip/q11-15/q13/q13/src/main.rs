fn fibonacci_sequence(n: u32) -> Vec<u64> {
    let mut sequence: Vec<u64> = Vec::with_capacity(n as usize);

    if n >= 1 {
        sequence.push(0);
    }
    if n >= 2 {
        sequence.push(1);
    }

    while sequence.len() < n as usize {
        let next_number = sequence[sequence.len() - 1] + sequence[sequence.len() - 2];
        sequence.push(next_number);
    }

    sequence
}

fn main() {
    let n = 9; 

    let fibonacci_sequence =fibonacci_sequence(n);

    println!("Fibonacci Sequence (first {} terms): {:?}", n, fibonacci_sequence);
}
