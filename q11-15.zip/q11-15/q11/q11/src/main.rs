fn find_largest(numbers: &[i32]) -> Option<i32> {

    let mut largest = numbers[0];

    for &num in numbers.iter() {
        if num > largest {
            largest = num;
        }
    }

    Some(largest)
}

fn main() {
    let numbers = [47, 12, 8, 132, 89, 1, 25]; 
    match find_largest(&numbers) {
        Some(largest) => println!("The largest number is: {}", largest),
        None => println!("The array is empty."),
    }
}
